create definer = root@localhost event Letno on schedule
    every '30' SECOND
        starts '2024-05-03 20:33:17'
    enable
    do
    BEGIN
        CALL UpdateNarocnine('letno');
    END;

