create
    definer = root@localhost procedure KarticaUporabnika(IN ime varchar(255), IN `limit` decimal(10, 2),
                                                         IN stanje decimal(10, 2))
BEGIN
    DECLARE uporabnik_id INT;
    DECLARE obstaja INT;

    SELECT COUNT(*) INTO obstaja FROM uporabniki WHERE ime = ime;

    IF obstaja = 1 THEN
        SELECT id_uporabnika INTO uporabnik_id FROM uporabniki WHERE ime = ime LIMIT 1;

        INSERT INTO kartica (id_uporabnika, `limit`, stanje)
        VALUES (uporabnik_id, `limit`, stanje);

        SELECT 'Card created successfully' AS message;
    ELSE
        SELECT 'User does not exist' AS message;
    END IF;
END;

