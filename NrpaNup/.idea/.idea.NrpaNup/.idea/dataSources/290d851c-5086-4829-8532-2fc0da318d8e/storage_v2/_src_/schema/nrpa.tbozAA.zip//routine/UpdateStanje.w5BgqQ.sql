create
    definer = root@localhost procedure UpdateStanje(IN id int)
BEGIN
    DECLARE vsota_mesecno DECIMAL(10, 2);
    DECLARE  odplacila INT;
    
    -- Trganje z racuna za kredit
    SELECT mesecno_odplacilo, st_odplacil 
    INTO  vsota_mesecno,odplacila
    FROM kreditiU
    WHERE id_uporabnika = id;
    
    IF vsota_mesecno IS NOT NULL  THEN
    UPDATE kartica
    SET stanje = stanje - vsota_mesecno
    WHERE id_uporabnika = id
    AND vrsta = 'debitna';
    END IF;
    
    IF odplacila IS NOT NULL  THEN
        UPDATE  kreditiU
            SET  st_odplacil = st_odplacil -1
        WHERE  id_uporabnika = id;
    end if;
   
    IF odplacila IS NULL  THEN
        DELETE FROM kreditiU
            WHERE odplacila = 0;
    end if;
END;

