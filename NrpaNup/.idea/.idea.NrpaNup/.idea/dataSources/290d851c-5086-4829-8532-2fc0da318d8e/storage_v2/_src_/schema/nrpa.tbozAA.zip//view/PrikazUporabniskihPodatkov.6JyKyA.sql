create definer = root@localhost view PrikazUporabniskihPodatkov as
select `nrpa`.`uporabniki`.`id_uporabnika`    AS `uporabnik_id`,
       `nrpa`.`uporabniki`.`ime`              AS `uporabnik_ime`,
       `nrpa`.`uporabniki`.`geslo`            AS `uporabnik_geslo`,
       `nrpa`.`uporabniki`.`created`          AS `uporabnik_created`,
       `nrpa`.`uporabniki`.`vrsta_uporabnika` AS `uporabnik_vrsta`,
       `nrpa`.`kartica`.`id_kartica`          AS `kartica_id`,
       `nrpa`.`kartica`.`st_kartice`          AS `kartica_st`,
       `nrpa`.`kartica`.`limit`               AS `kartica_limit`,
       `nrpa`.`kartica`.`vrsta`               AS `kartica_vrsta`,
       `nrpa`.`kartica`.`status`              AS `kartica_status`,
       `nrpa`.`kartica`.`stanje`              AS `kartica_stanje`,
       `nrpa`.`kartica`.`veljavnost`          AS `kartica_veljavnost`
from (`nrpa`.`uporabniki` join `nrpa`.`kartica`
      on (`nrpa`.`uporabniki`.`id_uporabnika` = `nrpa`.`kartica`.`id_uporabnika`));

