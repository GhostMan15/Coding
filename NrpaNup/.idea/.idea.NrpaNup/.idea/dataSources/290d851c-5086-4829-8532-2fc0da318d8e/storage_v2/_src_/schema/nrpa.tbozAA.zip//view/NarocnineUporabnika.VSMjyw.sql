create definer = root@localhost view NarocnineUporabnika as
select `nu`.`id_uporabnika`   AS `id_uporabnika`,
       `n`.`id_narocnine`     AS `narocnine_pk`,
       `nu`.`id_narocnine`    AS `narocnine_fk`,
       `nu`.`vsota_narocnine` AS `vsota_narocnine`,
       `nu`.`id_kartica`      AS `id_kartica_fk`,
       `k`.`id_kartica`       AS `id_kartica_pk`,
       `k`.`vrsta`            AS `vrsta`,
       `n`.`ime_narocnine`    AS `ime_narocnine`,
       `nu`.`tip_narocnine`   AS `tip_narocnine`
from (((`nrpa`.`narocnine` `n` join `nrpa`.`narocnineU` `nu`
        on (`n`.`id_narocnine` = `nu`.`id_narocnine`)) join `nrpa`.`kartica`) join `nrpa`.`kartica` `k`
      on (`nu`.`id_kartica` = `k`.`id_kartica`));

