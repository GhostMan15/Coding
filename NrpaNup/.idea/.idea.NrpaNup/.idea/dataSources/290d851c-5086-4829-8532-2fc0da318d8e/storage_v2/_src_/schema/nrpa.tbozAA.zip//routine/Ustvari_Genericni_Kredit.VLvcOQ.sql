create
    definer = root@localhost procedure Ustvari_Genericni_Kredit(IN vsota int, IN tip_kredita varchar(255), IN fixna_obrestna_mera int)
BEGIN
    DECLARE obrestna_mera DECIMAL(5, 2);

    -- Convert integer interest rate to decimal
    SET obrestna_mera = fixna_obrestna_mera / 100.0;

    -- Insert data into 'krediti' table
    INSERT INTO krediti(vsota, tip_kredita, fixna_obrestna_mera)
    VALUES(vsota, tip_kredita, obrestna_mera);
END;

