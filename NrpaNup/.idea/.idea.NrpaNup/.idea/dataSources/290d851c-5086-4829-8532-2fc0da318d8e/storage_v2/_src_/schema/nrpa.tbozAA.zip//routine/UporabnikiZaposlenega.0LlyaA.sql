create
    definer = root@localhost procedure UporabnikiZaposlenega(IN id_zaposlen int)
BEGIN
    SELECT u.id_uporabnika, u.ime AS ime, u.geslo, u.created, u.vrsta_uporabnika,
           k.id_kartica, k.st_kartice, k.`limit`, k.vrsta AS kartica_vrsta,
           k.status AS kartica_status, k.stanje AS kartica_stanje, k.veljavnost AS kartica_veljavnost
    FROM uporabniki u
             JOIN zaposlen z ON u.id_uporabnika = z.id_uporabnika
             JOIN kartica k ON u.id_uporabnika = k.id_uporabnika
    WHERE z.id_zaposlen = id_zaposlen;
END;

