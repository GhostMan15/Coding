create
    definer = root@localhost procedure Uporabniskikrediti(IN id int)
BEGIN 

SELECT u.id_uporabnika, u.ime, u.geslo, u.created, u.vrsta_uporabnika,
       k.id_kartica, k.st_kartice, k.`limit`, k.vrsta AS kartica_vrsta,
       k.status, k.stanje , k.veljavnost,
       ku.id, ku.id_kartica, ku.cas, ku.id_krediti, ku.mesecno_odplacilo,
       ku.st_odplacil, k2.vsota, k2.fixna_obrestna_mera,
       k2.tip_kredita, z.id_zaposlen, z.ime 
FROM uporabniki u
         JOIN zaposlen z ON u.id_uporabnika = z.id_uporabnika
         JOIN kartica k ON u.id_uporabnika = k.id_uporabnika
         JOIN kreditiU ku ON k.id_kartica = ku.id_kartica
         JOIN krediti k2 ON k2.id_krediti = ku.id_krediti
WHERE z.id_zaposlen = id;
END;

