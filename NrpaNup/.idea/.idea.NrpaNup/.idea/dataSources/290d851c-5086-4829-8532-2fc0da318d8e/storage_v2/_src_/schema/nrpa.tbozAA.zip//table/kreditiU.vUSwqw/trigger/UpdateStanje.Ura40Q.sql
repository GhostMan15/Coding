create definer = root@localhost trigger UpdateStanje
    after insert
    on kreditiU
    for each row
BEGIN

    DECLARE krediti_vsota DECIMAL(10, 2);
    
    SELECT vsota INTO krediti_vsota FROM krediti WHERE id_krediti = NEW.id_krediti;
    UPDATE kartica
    SET stanje = stanje + krediti_vsota
    WHERE id_kartica = NEW.id_kartica;
        
END;

