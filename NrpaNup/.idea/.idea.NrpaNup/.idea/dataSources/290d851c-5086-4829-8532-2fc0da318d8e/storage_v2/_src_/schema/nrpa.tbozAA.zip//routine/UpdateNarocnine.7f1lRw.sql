create
    definer = root@localhost procedure UpdateNarocnine(IN id int)
BEGIN
    DECLARE narocnina INT;
    DECLARE  id_kar INT;
    DECLARE tip_naroc ENUM('mesecno', 'letno');
    -- Trganje z racuna za narocnine
    SELECT vsota_narocnine, id_kartica, tip_narocnine 
    INTO narocnina, id_kar, tip_naroc
    FROM narocnineU
    WHERE id_uporabnika = id
    AND  id_kartica = id_kar;

    IF tip_naroc = 'mesecno' THEN
        IF narocnina IS NOT NULL THEN
            UPDATE kartica
            SET stanje = stanje - narocnina
            WHERE id_uporabnika = id
              AND id_kartica = id_kar;
        END IF;
      
    ELSEIF tip_naroc = 'letno' THEN
        IF narocnina IS NOT NULL THEN
            UPDATE kartica
            SET stanje = stanje - narocnina
            WHERE id_uporabnika = id
              AND id_kartica = id_kar;
        END IF;
    END IF;
end;

