create definer = root@localhost event UpdateStanjeEvent on schedule
    every '10' SECOND
        starts '2024-05-03 15:39:31'
    enable
    do
    BEGIN
        CALL UpdateStanje();
    END;

