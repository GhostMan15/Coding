create definer = root@localhost view KreditiUporabnika as
select `u`.`id_uporabnika`       AS `uporabnik_id`,
       `u`.`ime`                 AS `ime`,
       `k`.`id_krediti`          AS `id_krediti`,
       `k`.`vsota`               AS `vsota`,
       `k`.`fixna_obrestna_mera` AS `fixna_obrestna_mera`,
       `d`.`id`                  AS `kredit_fk`,
       `d`.`cas`                 AS `cas`,
       `d`.`mesecno_odplacilo`   AS `mesecno_odplacilo`,
       `kc`.`stanje`             AS `stanje`
from (((`nrpa`.`uporabniki` `u` join `nrpa`.`kreditiU` `d`
        on (`u`.`id_uporabnika` = `d`.`id_uporabnika`)) join `nrpa`.`krediti` `k`
       on (`d`.`id_krediti` = `k`.`id_krediti`)) join `nrpa`.`kartica` `kc`
      on (`u`.`id_uporabnika` = `kc`.`id_uporabnika`));

