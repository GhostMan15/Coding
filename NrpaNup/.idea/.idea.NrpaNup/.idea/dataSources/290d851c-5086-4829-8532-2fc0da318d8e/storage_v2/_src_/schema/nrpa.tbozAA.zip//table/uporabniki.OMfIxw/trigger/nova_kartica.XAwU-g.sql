create definer = root@localhost trigger nova_kartica
    after insert
    on uporabniki
    for each row
BEGIN
    
    SET @st_kartice = CONCAT('SI',  SUBSTRING(LPAD(FLOOR(RAND() * 999999999), 12, '0'), 1, 2), ' ',
                             SUBSTRING(LPAD(FLOOR(RAND() * 999999), 6, '0'), 1, 4), ' ',
                             SUBSTRING(LPAD(FLOOR(RAND() * 999999), 6, '0'), 1, 4), ' ',
                             SUBSTRING(LPAD(FLOOR(RAND() * 99999), 5, '0'), 1, 5));



    SET @status = 'veljavna';
    SET @veljavnost = DATE_ADD(NOW(), INTERVAL 5 YEAR);

    
    INSERT INTO kartica (id_uporabnika, st_kartice, `limit`, vrsta, status, stanje, veljavnost)
    VALUES (NEW.id_uporabnika, @st_kartice, DEFAULT, DEFAULT, @status, DEFAULT, @veljavnost);
END;

