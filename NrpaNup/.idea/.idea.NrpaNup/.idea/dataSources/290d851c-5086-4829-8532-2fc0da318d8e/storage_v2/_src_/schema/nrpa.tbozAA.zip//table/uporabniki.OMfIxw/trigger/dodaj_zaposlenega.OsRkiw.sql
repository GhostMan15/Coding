create definer = root@localhost trigger dodaj_zaposlenega
    after insert
    on uporabniki
    for each row
BEGIN
    IF NEW.vrsta_uporabnika = 'zaposlen' THEN
        INSERT INTO zaposlen (id_zaposlen, ime, geslo)
        VALUES (NEW.id_uporabnika, NEW.ime, NEW.geslo);
    END IF;
END;

