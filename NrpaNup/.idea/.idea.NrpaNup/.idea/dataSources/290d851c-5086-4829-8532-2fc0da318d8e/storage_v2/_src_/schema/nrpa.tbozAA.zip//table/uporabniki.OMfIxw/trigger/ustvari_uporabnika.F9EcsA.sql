create definer = root@localhost trigger ustvari_uporabnika
    before insert
    on uporabniki
    for each row
BEGIN
    DECLARE generirano_geslo INT;

    
    SET generirano_geslo = FLOOR(RAND() * 9000) + 1000;

    
    SET NEW.geslo = generirano_geslo;
    SET NEW.created = NOW();
    SET NEW.vrsta_uporabnika = COALESCE(NEW.vrsta_uporabnika, 'uporabnik');
END;

