create definer = root@localhost trigger ustvari_uporabnika
    after insert
    on uporabniki
    for each row
BEGIN
    DECLARE generirano_geslo INT;
    
    
    SET generirano_geslo = FLOOR(RAND() * 9000) + 1000;

    
    UPDATE uporabniki
    SET geslo = generirano_geslo,
        created = NOW(),
        vrsta_uporabnika = COALESCE(NEW.vrsta_uporabnika, 'uporabnik')
    WHERE id_uporabnika = NEW.id_uporabnika;
END;

