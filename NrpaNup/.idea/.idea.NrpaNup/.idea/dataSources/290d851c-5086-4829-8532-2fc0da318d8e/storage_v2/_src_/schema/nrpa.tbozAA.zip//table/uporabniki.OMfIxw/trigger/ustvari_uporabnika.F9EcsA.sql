create definer = root@localhost trigger ustvari_uporabnika
    before insert
    on uporabniki
    for each row
BEGIN
    DECLARE generirano_geslo INT;
    DECLARE  vrsta_uporabnika VARCHAR(255);
    
    SET generirano_geslo = FLOOR(RAND() * 9000) + 1000;
    SET vrsta_uporabnika = NEW.vrsta_uporabnika;
    
    SET NEW.geslo = generirano_geslo;
    SET NEW.created = NOW();
    IF vrsta_uporabnika = 'zaposlen' THEN
        SET  NEW.vrsta_uporabnika = 'zaposlen';
    ELSE
        SET NEW.vrsta_uporabnika = 'uporabnik';
    END IF;
END;

