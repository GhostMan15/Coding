create
    definer = root@localhost procedure UstvariNarocnino(IN p_ime_narocnine varchar(255), IN p_vsota_mesecno decimal(10, 2))
BEGIN
    DECLARE v_vsota_letno DECIMAL(10,2);

    SET v_vsota_letno = p_vsota_mesecno * 12 * (1 - 0.20); -- 20% discount for yearly

    INSERT INTO narocnine (ime_narocnine, vsota_mesecno, vsota_letno) VALUES (p_ime_narocnine, p_vsota_mesecno, v_vsota_letno);
END;

