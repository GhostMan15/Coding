create
    definer = root@localhost procedure Vpis(IN ime varchar(255), IN geslo varchar(255))
BEGIN
    SELECT id_uporabnika, ime, geslo, vrsta_uporabnika
    FROM uporabniki 
    WHERE uporabniki.ime = ime AND uporabniki.geslo = geslo;
END;

