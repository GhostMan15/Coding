create definer = root@localhost trigger preverjanje_gesla
    before insert
    on uporabniki
    for each row
BEGIN
    DECLARE password_count INT;

    SELECT COUNT(*) INTO password_count FROM uporabniki WHERE geslo = NEW.geslo;

    IF password_count > 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Podvojeno geslo';
    END IF;
END;

