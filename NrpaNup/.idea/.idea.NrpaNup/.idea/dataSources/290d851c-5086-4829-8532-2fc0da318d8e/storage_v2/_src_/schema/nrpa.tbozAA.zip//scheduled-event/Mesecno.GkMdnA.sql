create definer = root@localhost event Mesecno on schedule
    every '10' SECOND
        starts '2024-05-03 20:33:08'
    enable
    do
    BEGIN
        CALL UpdateNarocnine('mesecno');
    END;

