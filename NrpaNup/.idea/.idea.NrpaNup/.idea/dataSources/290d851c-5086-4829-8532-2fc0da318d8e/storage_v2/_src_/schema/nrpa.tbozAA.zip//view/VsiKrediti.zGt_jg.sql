create definer = root@localhost view VsiKrediti as
select `nrpa`.`krediti`.`id_krediti`          AS `id_krediti`,
       `nrpa`.`krediti`.`vsota`               AS `vsota`,
       `nrpa`.`krediti`.`tip_kredita`         AS `tip_kredita`,
       `nrpa`.`krediti`.`fixna_obrestna_mera` AS `fixna_obrestna_mera`
from `nrpa`.`krediti`;

