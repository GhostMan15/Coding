create
    definer = root@localhost procedure Izracun(IN vsota decimal(10, 2), IN obrestna_mera decimal(5, 2), IN cas int)
BEGIN
    DECLARE mesecna_obrestna_mera DECIMAL(5,4);
    DECLARE koliko_mesecov INT;
    DECLARE mesecno_odplacilo DECIMAL(10,2);


    SET mesecna_obrestna_mera = obrestna_mera / 12 / 100;

    SET koliko_mesecov = cas * 12;

    SET mesecno_odplacilo = (vsota * mesecna_obrestna_mera) / (1 - POW(1 + mesecna_obrestna_mera, - koliko_mesecov));

    SELECT mesecno_odplacilo;
END;

